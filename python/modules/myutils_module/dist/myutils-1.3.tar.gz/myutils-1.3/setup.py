from setuptools import setup

setup(name='myutils',
      version='1.3',
      description='Módulo de Python auxiliar.',
      author='gds',
      packages=['myutils'],
      zip_safe=False)
