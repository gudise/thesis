from setuptools import setup

setup(name='myutils',
      version='1.2',
      description='Módulo de Python auxiliar.',
      author='gds',
      packages=['myutils'],
      zip_safe=False)
