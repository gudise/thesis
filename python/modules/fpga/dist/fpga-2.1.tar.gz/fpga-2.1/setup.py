from setuptools import setup

setup(name='fpga',
      version='2.1',
      description='Módulo de Python para el proyecto fpga.',
      author='gds',
      packages=['fpga'],
      zip_safe=False)
	