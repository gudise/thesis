from setuptools import setup

setup(name='fpga',
      version='1.3',
      description='Módulo de Python para el proyecto fpga.',
      author='gds',
      packages=['fpga', 'fpga.interfaz_pc'],
      zip_safe=False)