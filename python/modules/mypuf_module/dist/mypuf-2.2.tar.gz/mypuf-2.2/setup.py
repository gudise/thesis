from setuptools import setup

setup(name='mypuf',
      version='2.2',
      description='Módulo de Python para el proyecto puf.',
      author='gds',
      packages=['mypuf'],
      zip_safe=False)
