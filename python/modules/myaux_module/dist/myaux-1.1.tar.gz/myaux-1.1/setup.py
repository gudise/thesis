from setuptools import setup

setup(name='myaux',
      version='1.1',
      description='Módulo de Python auxiliar.',
      author='gds',
      packages=['myaux'],
      zip_safe=False)
