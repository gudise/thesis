from setuptools import setup

setup(name='myfpga',
      version='2.91',
      description='Módulo de Python para el proyecto fpga.',
      author='gds',
      packages=['myfpga'],
      zip_safe=False)
