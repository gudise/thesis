from setuptools import setup

setup(name='myfpga',
      version='2.7',
      description='Módulo de Python para el proyecto fpga.',
      author='gds',
      packages=['myfpga'],
      zip_safe=False)
