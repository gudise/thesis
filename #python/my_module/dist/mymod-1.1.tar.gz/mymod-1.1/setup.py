from setuptools import setup

setup(name='mymod',
      version='1.1',
      description='My python module',
      author='gds',
      packages=['mymod'],
      zip_safe=False)